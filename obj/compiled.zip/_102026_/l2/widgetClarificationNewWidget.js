/// <mls fileReference="_102026_/l2/widgetClarificationNewWidget.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { convertFileNameToTag, convertTagToFileName } from '/_102027_/l2/utils.js';
let WcClarificationPlannerNewWidget100554 = class WcClarificationPlannerNewWidget100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-clarification-new-widget-102026{font-family:Arial,sans-serif;padding:20px;font-size:var(--font-size-12)}widget-clarification-new-widget-102026 input,widget-clarification-new-widget-102026 select,widget-clarification-new-widget-102026 textarea{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}widget-clarification-new-widget-102026 button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}widget-clarification-new-widget-102026 .section{margin-bottom:20px;padding:15px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}widget-clarification-new-widget-102026 .section h2{margin-top:0;text-transform:capitalize}widget-clarification-new-widget-102026 .property,widget-clarification-new-widget-102026 .requirement{margin-left:20px;margin-top:5px;width:calc(100% - 20px)}widget-clarification-new-widget-102026.readonly .buttons{display:none !important}widget-clarification-new-widget-102026 .buttons{margin-top:30px;display:flex;gap:1rem}widget-clarification-new-widget-102026 .error{font-weight:bold;color:var(--error-color)}widget-clarification-new-widget-102026 .cancel{background-color:var(--warning-color);color:white}widget-clarification-new-widget-102026 .cancel:hover{background-color:var(--warning-color-hover)}widget-clarification-new-widget-102026 .continue{background-color:var(--success-color);color:white}widget-clarification-new-widget-102026 .continue:hover{background-color:var(--success-color-hover)}`);
        this.ICABASEPROJECT = mls.actualProject || 100554;
        this.folder = '';
        this.error = '';
        this.develpoment = false;
        this.mode = 'write';
    }
    render() {
        if (this.mode === 'readonly')
            this.classList.add('readonly');
        else
            this.classList.remove('readonly');
        if (this.develpoment)
            this.setDevelpoment();
        if (this.error) {
            return html `
                <div>${this.data?.clarificationMessage}</div>
                <small class="error">${this.data?.clarificationMessage}</small>

                <div class="buttons">
                    <button class="cancel" @click=${this.handleCancel}>Cancelar</button>
                </div>
            `;
        }
        return html `

        <div>${this.data?.clarificationMessage}</div>
        <div>
            ${this.data?.json?.map((item) => {
            switch (item.sectionName) {
                case 'resume':
                    return this.renderResume(item);
                case 'parentClass':
                    return this.renderParentClass(item);
                case 'widgetName':
                    return this.renderWidgetName(item);
                case 'properties':
                    return this.renderProperties(item);
                case 'requirements':
                    return this.renderRequirements(item);
            }
        })}
            <div class="buttons">
                <button class="cancel" @click=${this.handleCancel}>Cancelar</button>
                <button class="continue" @click=${this.handleOk}>Continuar</button>
            </div>

        </div>`;
    }
    renderResume(item) {
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
            </div>
        `;
    }
    renderParentClass(item) {
        item.widgetName = this.createParentName(item.widgetName);
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
                <div>
                    <label>Parent Class:</label>
                    <input
                        @input= ${(e) => this.handleParentInput(e, item)} 
                        type="text"
                        readonly
                        style="border:none"
                        .value=${item.widgetName}
                    ></input>
                </div>
            </div>
        `;
    }
    renderWidgetName(item) {
        if (!item.folder) {
            const base = this.getBase();
            item.folder = `molecules/${base}`;
            item.project = mls.actualProject || 0;
            this.folder = item.folder;
        }
        item.tagName = this.createTagName(item.tagName, item.folder);
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
                <div>
                    <label>Widget:</label>
                    <input
                        type="text"
                        .value=${item.widgetName}
                        @input= ${(e) => this.handleWidgetNameInput(e, item)} 
                    ></input>
                    <small style="color:red" id="widgetNameError"></small>
                </div>
                <div style="margin-top:.5rem">
                    <label>Folder:</label>
                    <input
                        id="input_folder"
                        type="text"
                        readonly
                        style="border:none"
                        .value=${item.folder}
                    ></input>
                </div>
                <div style="margin-top:.5rem">
                    <label>Tagname:</label>
                    <input
                        id="input_tagName"
                        type="text"
                        readonly
                        style="border:none"
                        @change=${(e) => this.handleTagNameChange(e, item)}
                        .value=${item.tagName}
                    ></input>
                </div>
            </div>
        `;
    }
    renderProperties(item) {
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
                <ul>
                    ${item.properties.map((prop) => html `<li><b>${prop.propertyName}:</b> ${prop.description} (Essencial: ${prop.isEssencial}</li>`)}
                </ul>
            </div>
        `;
    }
    renderRequirements(item) {
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
                
                <h3>Functional Requirements:</h3>
                ${item.functionalRequirements
            ? html `
                        <textarea
                            rows=${item.functionalRequirements.length}
                            .value = "- ${item.functionalRequirements.join('\n -')}"
                            @input=${(e) => this.handleRqFunctionalInput(e, item)}
                        >
                        </textarea>
                    `
            : ''}

                <h3>Visual Requirements</h3>
                ${item.visualRequirements
            ? html `
                        <textarea
                            rows=${item.visualRequirements.length}
                            .value = "- ${item.visualRequirements.join('\n -')}"
                            @input=${(e) => this.handleRqVisualInput(e, item)}
                        >
                        </textarea>
                    `
            : ''}

            </div>
        `;
    }
    createTagName(value, folder = '') {
        const valueWithoutProject = this.removeTrailingPattern(value);
        const project = mls.actualProject;
        if (!project)
            return valueWithoutProject;
        return convertFileNameToTag({ project, shortName: valueWithoutProject, folder });
    }
    removeTrailingPattern(str) {
        return str.replace(/-\d{6}$/, '');
    }
    createParentName(value) {
        const info = convertTagToFileName(`${value}-${this.ICABASEPROJECT}`);
        if (!info)
            return '';
        let newParentName = info.shortName;
        newParentName = newParentName.endsWith('Base') ? newParentName : `${newParentName}`;
        return newParentName.charAt(0).toLowerCase() + newParentName.slice(1);
        ;
    }
    handleWidgetNameInput(e, item) {
        const target = e.target;
        const key = mls.stor.getKeyToFiles(this.ICABASEPROJECT, 2, target.value, '', '.ts');
        if (!this.widgetNameError)
            return;
        if (mls.stor.files[key]) {
            this.widgetNameError.innerHTML = "A widget with this name already exists";
            return;
        }
        ;
        if (!target.value.startsWith('widget')) {
            this.widgetNameError.innerHTML = "Component name must start with \"widget\"";
            return;
        }
        this.widgetNameError.innerHTML = "";
        item.widgetName = target.value;
        if (this.inputTag) {
            this.inputTag.value = this.createTagName(target.value, this.folder);
            const event = new Event('change', { bubbles: true });
            this.inputTag.dispatchEvent(event);
        }
    }
    handleTagNameChange(e, item) {
        const target = e.target;
        item.tagName = target.value.charAt(0).toLowerCase() + target.value.slice(1);
    }
    handleParentInput(e, item) {
        const target = e.target;
        item.widgetName = target.value;
    }
    handleRqVisualInput(e, item) {
        const target = e.target;
        item.visualRequirements = target.value.split('\n');
    }
    handleRqFunctionalInput(e, item) {
        const target = e.target;
        item.functionalRequirements = target.value.split('\n');
    }
    handleCancel() {
        this.handleAction('cancel');
    }
    handleOk() {
        let hasError = false;
        this.data?.json?.map((item) => {
            if (item.sectionName === 'widgetName') {
                const key = mls.stor.getKeyToFiles(this.ICABASEPROJECT, 2, item.widgetName, '', '.ts');
                if (!this.widgetNameError)
                    return;
                if (mls.stor.files[key]) {
                    this.widgetNameError.innerHTML = "A widget with this name already exists";
                    hasError = true;
                    return;
                }
                ;
                if (!item.widgetName.startsWith('widget')) {
                    this.widgetNameError.innerHTML = "Component name must start with \"widget\"";
                    hasError = true;
                    return;
                }
            }
        });
        if (hasError)
            return;
        this.handleAction('continue');
    }
    async handleAction(action) {
        if (!this.data)
            return;
        if (this.develpoment) {
            console.info(this.data);
            return;
        }
        //await postBackClarification(action, this.data);
    }
    getBase() {
        if (!this.data)
            return '';
        let ret = '';
        this.data.json?.map((item) => {
            if (item.sectionName === 'parentClass') {
                ret = item.widgetName;
            }
        });
        return ret;
    }
    setDevelpoment() {
        this.data = {
            clarificationMessage: '',
            stepId: 123,
            taskId: '123',
            json: [{ "sectionName": "resume", "description": "Widget para seleção de intervalo de datas, com suporte a limites mínimo/máximo, bloqueio de datas específicas e validação visual clara. Ideal para reservas e agendamentos." }, { "sectionName": "parentClass", "description": "Component for selecting date ranges, useful for period filters.", "widgetName": "IcaFormsInputDateRange" }, { "sectionName": "widgetName", "description": "Nome do Widget", "widgetName": "widgetDateRangeBooking", "tagName": "widget-date-range-booking-100555" }, { "sectionName": "properties", "description": "Propriedades do widget", "properties": [{ "propertyName": "label", "description": "Texto exibido acima do campo de seleção.", "isEssencial": "false" }, { "propertyName": "hint", "description": "Dica ou instrução para o usuário.", "isEssencial": "false" }, { "propertyName": "errormessage", "description": "Mensagem de erro personalizada.", "isEssencial": "false" }, { "propertyName": "name", "description": "Nome do campo para integração com formulários.", "isEssencial": "false" }, { "propertyName": "startvalue", "description": "Data inicial selecionada.", "isEssencial": "false" }, { "propertyName": "endvalue", "description": "Data final selecionada.", "isEssencial": "false" }, { "propertyName": "required", "description": "Define se o campo é obrigatório.", "isEssencial": "false" }, { "propertyName": "disabled", "description": "Desabilita o componente.", "isEssencial": "false" }, { "propertyName": "readonly", "description": "Torna o campo somente leitura.", "isEssencial": "false" }, { "propertyName": "autofocus", "description": "Foca automaticamente no campo ao carregar.", "isEssencial": "false" }, { "propertyName": "minvalue", "description": "Data mínima permitida para seleção.", "isEssencial": "false" }, { "propertyName": "maxvalue", "description": "Data máxima permitida para seleção.", "isEssencial": "false" }, { "propertyName": "blockedDates", "description": "Lista de datas específicas que não podem ser selecionadas (essencial).", "isEssencial": "true" }, { "propertyName": "dropdown", "description": "Exibe o seletor de datas em formato dropdown (essencial).", "isEssencial": "true" }, { "propertyName": "errorPosition", "description": "Posiciona a mensagem de erro acima do componente (essencial).", "isEssencial": "true" }] }, { "sectionName": "requirements", "description": "requisitos para este widget, altere se necessário", "functionalRequirements": ["O usuário deve clicar primeiro na data inicial e depois na data final para confirmar o intervalo.", "A data inicial deve ser obrigatoriamente menor que a data final.", "Cada dia na tabela de datas deve ser um botão clicável.", "Deve ser possível definir datas bloqueadas que não podem ser selecionadas.", "Após a seleção, o componente deve atualizar e exibir o período escolhido, refletindo na propriedade do web-componente.", "O componente deve emitir eventos ou atualizar propriedades para integração com formulários externos."], "visualRequirements": ["O seletor de datas deve ser exibido em formato dropdown.", "A mensagem de erro deve aparecer acima do componente, nunca abaixo.", "Datas bloqueadas devem ser visualmente diferenciadas e não interativas.", "Datas selecionadas (inicial e final) devem ser destacadas.", "O período selecionado deve ser claramente exibido após a seleção."] }]
        };
    }
};
__decorate([
    property()
], WcClarificationPlannerNewWidget100554.prototype, "data", void 0);
__decorate([
    property()
], WcClarificationPlannerNewWidget100554.prototype, "error", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], WcClarificationPlannerNewWidget100554.prototype, "develpoment", void 0);
__decorate([
    property({ type: String, reflect: true })
], WcClarificationPlannerNewWidget100554.prototype, "mode", void 0);
__decorate([
    query('#input_tagName')
], WcClarificationPlannerNewWidget100554.prototype, "inputTag", void 0);
__decorate([
    query('#widgetNameError')
], WcClarificationPlannerNewWidget100554.prototype, "widgetNameError", void 0);
WcClarificationPlannerNewWidget100554 = __decorate([
    customElement('widget-clarification-new-widget-102026')
], WcClarificationPlannerNewWidget100554);
export { WcClarificationPlannerNewWidget100554 };
