/// <mls fileReference="_102026_/l2/molecules/selectone/index.test.ts" enhancement="_102027_/l2/enhancementLit" />
export const integrations = [];
export const tests = [];
