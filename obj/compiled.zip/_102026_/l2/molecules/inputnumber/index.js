/// <mls shortName="index" project="102026" enhancement="_blank" folder="molecules/inputnumber" />
export const widgetDefinition = {
    name: "inputnumber",
    description: "Campo para inserir um número",
    properties: [
        { name: "value", type: "number" }
    ]
};
