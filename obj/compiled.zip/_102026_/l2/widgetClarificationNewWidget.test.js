/// <mls fileReference="_102026_/l2/widgetClarificationNewWidget.test.ts" enhancement="_102027_/l2/enhancementLit" />
export const integrations = [];
export const tests = [];
