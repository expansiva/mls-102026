/// <mls fileReference="_102026_/l2/project.ts" enhancement="_blank" />
export const projectConfig = {
    masterFrontEnd: {
        build: '',
        start: '',
        liveView: '',
    },
    masterBackEnd: {
        build: '',
        start: '',
        serverView: ''
    },
    modules: []
};
